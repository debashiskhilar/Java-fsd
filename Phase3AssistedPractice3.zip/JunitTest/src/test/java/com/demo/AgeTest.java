package com.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class AgeTest {
	static AgeValidator validobj;
	@BeforeAll
	public static void init() {
		validobj=new AgeValidator();
	}
	
	@Test
	public void test1() {
		String actual=validobj.agevalidate(18);
		String expect="right to vote";
		assertEquals(expect, actual);
	}
	@Test
	public void test2() {
		String actual=validobj.agevalidate(8);
		String expect="not eligible to vote";
		assertEquals(expect, actual);
	}
	
	@AfterAll
	public static void aftereachtest() {
		validobj=null;
	}

}

package com.demo;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class UserAuthenticationTest {
	
	
	@Test
    public void testSuccessfulAuthentication() {
		UserAuthentication userAuthentication = new UserAuthentication();
        assertTrue(userAuthentication.authenticate("admin", "password"));
    }

    @Test
    public void testFailedAuthentication() {
        UserAuthentication userAuthentication = new UserAuthentication();
        assertFalse(userAuthentication.authenticate("differentUser", "wrongPassword"));
    }

}

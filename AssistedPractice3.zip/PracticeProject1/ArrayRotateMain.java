package PracticeProject1;

public class ArrayRotateMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int mainArray[] = new int[] {1,2,3,4,5,6,7};
		int steps = 5;
		int length = mainArray.length;
		
		int newArray[] = new int[length];

		for(int i=0;i<length;i++) {
			int newPos = (i+steps)%length;
			newArray[newPos] = mainArray[i];
		}
		
		System.out.println("The Main array is ");
		for(int val:mainArray) {
			System.out.print(val+" ");
		}
		System.out.println("\nThe Rotated array is ");
		for(int val:newArray) {
			System.out.print(val+" ");
		}
	}
}

package PracticeProject3;

class RangeSum{
	int arr[] = new int[] {2,4,6,8,10};
	void sumOfRange(int L,int R) {
		int sum = 0;
		
		if(L<0 || R >= arr.length || L>R) {
			System.out.println("Not in the range");
		}
		else {
			for(int i=L;i<=R;i++) {
				sum = sum+arr[i];
			}
		}
		System.out.println("Sum of elements in range of "+L+" and "+R+" is -> "+sum);
	}
}

public class SumOfRange {
	public static void main(String[] args) {
		RangeSum rs = new RangeSum();
		rs.sumOfRange(2, 4);
	}
}

package PracticeProject9;

import java.util.Scanner;

public class Queue {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the size of a queue ");
		int size=sc.nextInt();

		int queue[] = new int[size];
		int front=-1;
		int rear=-1;
		while(true) {
			System.out.println();
			System.out.println("Enter your choice  1.Enqueue  2.Dequeue   3.DISPLAY  4.EXIT  ");
			int ch=sc.nextInt();
			switch(ch) {
			case 1: if(rear==size-1) {
				System.out.println("Overflow");
			}
			else if(rear==-1){
				System.out.println("No element yet, Enter element to insert ");
				int key=sc.nextInt();
				front=0;
				rear=0;
				queue[rear]=key;
			}
			else {
				System.out.println("No element yet, Enter element to insert ");
				int key=sc.nextInt();
				rear++;
				queue[rear]=key;
			}
			break;
			
			case 2: if(front==-1) {
				System.out.println("Underflow");
			}
			else if(front==rear){
				System.out.println("Only one elemet is there, delete it ");
				front=-1;
				rear=-1;
			}
			else {
				front++;
			}
			break;
			
			case 3: if(rear==-1) {
				System.out.println("Queue is empty ");
			}
			else {
				for(int i=front;i<=rear;i++) {
					System.out.print(queue[i]+"  ");
				}
			}
			break;  
			
			case 4:System.exit(0);
			break;
			
			default:System.out.println("check ur choice ");
			break;
			}
		}
	}
}


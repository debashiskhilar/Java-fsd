package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
        WebDriverManager.chromedriver().setup();
        WebDriver wd=new ChromeDriver();
        wd.manage().window().maximize();
        
        wd.get("http://localhost:4200/login");
        Thread.sleep(2000);
        wd.findElement(By.id("username")).sendKeys("admin");
        Thread.sleep(1000);
        wd.findElement(By.id("password")).sendKeys("123456");
        Thread.sleep(1000);
        wd.findElement(By.xpath("/html/body/app-root/div/app-login/div/form/button")).click();
        Thread.sleep(2000);
        wd.findElement(By.xpath("/html/body/app-root/div/app-employee-management/div/div/button")).click();
        Thread.sleep(2000);
        wd.findElement(By.id("first_name")).sendKeys("Karthik");
        Thread.sleep(1000);
        wd.findElement(By.id("last_name")).sendKeys("Kota");
        Thread.sleep(1000);
        wd.findElement(By.id("email")).sendKeys("Kk@gmail.com");
        Thread.sleep(1000);
        wd.findElement(By.xpath("/html/body/app-root/div/app-add-employee/div/form/button[1]")).click();
       
        Thread.sleep(2000);
        wd.close();
    }
}

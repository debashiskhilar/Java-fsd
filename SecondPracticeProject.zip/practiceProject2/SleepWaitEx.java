package practiceProject2;

public class SleepWaitEx {

	private static Object sleepObj = new Object();
	
	public static void main(String args[]) throws InterruptedException
	{
		Thread.sleep(2000);
		System.out.println("Thread '" + Thread.currentThread().getName() + "' is woken after sleeping for 2 second");
		synchronized (sleepObj) 
		{
			sleepObj.wait(2000);
			System.out.println("Object '" + sleepObj + "' is woken after" + " waiting for 2 second");
		}
	}
}
package practiceProject5;

import java.util.Scanner;

public class ThrowKeyword {

	static void check_roll(int x)
	{
		try
		{
			if(x<0)
				//throw is used to throw the exception occur
				throw new NumberFormatException("Negative value entered");
			else
				System.out.println("Congratulation... your rollno is verified");
		}
		catch(NumberFormatException ex)
		{
			System.out.println(ex);
			System.out.println("Please enter a positive no");
		}
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter roll no:");
		int r=sc.nextInt();
		check_roll(r);

	}

}

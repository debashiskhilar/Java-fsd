package practiceProject8;

public class PolymorphsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Polymorphs pmh = new Polymorphs();
		pmh.sum(5,10);
		pmh.sum(10.5, 2.3);
		pmh.sum(9,2,7);
	}

}

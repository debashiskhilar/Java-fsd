package practiceProject8;

public class EncapsulationEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encaps en = new Encaps();
		en.setEid(1);
		en.setEname("Debashis");
		en.setEmail("dk@jhsg");
		
		Encaps en1 = new Encaps();
		en1.setEid(2);
		en1.setEname("Khilar");
		en1.setEmail("gsd@gs");
		
		System.out.println(en);
		System.out.println(en1);
	}

}

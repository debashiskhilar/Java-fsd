package practiceProject8;

public class Polymorphs {
	
	void sum(int val1,int val2) {
		System.out.println("Sum of two int type value is "+(val1+val2));
	}
	void sum(double val1,double val2) {
		System.out.println("Sum of two double type value is"+(val1+val2));
	}
	void sum(int val1,int val2,int val3) {
		System.out.println("Sum of three int type value is "+(val1+val2+val3));
	}

}
